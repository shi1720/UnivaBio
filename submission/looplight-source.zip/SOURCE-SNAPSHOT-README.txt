Looplight source snapshot

All files selected by source-inventory.json are included at their repository paths.
SHA-256 values cover exact source bytes. Hash-listed support files are included,
including model weights, synthetic datasets, the lockfile and builder images.
Generated artifacts, dependency trees, private credentials and unselected files
are not part of this snapshot. Read README.md for setup and test commands.
The Firebase browser configuration is public and identifies the deployed project.
Use the documented isolated emulators or configure your own Firebase project
for independent testing. Do not deploy to another owner's project.
